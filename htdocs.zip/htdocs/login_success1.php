<?php
	if(!isset($_COOKIE['loggedin']))
	{
		header("location:index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
<title>Account</title>
<link href="stylesheet.css" rel="StyleSheet" />
<script src="jquery-1.12.0.min.js"></script>
<script src="script.js"></script>
</head>
	<body align="center">
	<h1><p style ="color: red">You have successfully logged as an Adminstrator into Examination Timetable Scheduling Software!</p></h1>
	
	<h3>
	<a href = "logout.php">Logout</a> <br>
	<a href = "addstudents.html">Add Student Credentials</a><br>
	<a href = "removestudents.html">Remove Students Credentials</a><br>
	<a href = "generatetimetable.php">Generate Timetable</a><br>
	<a href = "viewtimetable.php">View Timetable</a>

    </h3>
</html>