
<?php
	if(!isset($_COOKIE['loggedin']))
	{
		header("location:index.php");

	}
?>


<!DOCTYPE html>
<html>
<head>
<title>Account</title>
<link href="stylesheet.css" rel="StyleSheet" />
<script src="jquery-1.12.0.min.js"></script>
<script src="script.js"></script>
</head>
	<body align="center">
	<h3><p style="color: red">You have successfully logged as Student into Examination Timetable Scheduling Software!</p></h3>
	

	<a href = "logout.php"  style =" color:red" >   <h3>Logout</h3> </a> <br>
	<a href = "viewtimetable.php"  style ="color: red">  <h3> View Timetable </h3> </a>
</body>

</html>