<?php

	system('g++ main.cpp course.h date.h venue.h -o executable.exe');		//script line exeuuctes a command to run the c++ generate timetable 

	system('executable.exe');
	$file = 'timetable.csv';


	$username = "root";
	$password = "tphali";
	$hostname = "localhost";
	$dbhandle = mysql_connect($hostname, $username, $password) or die ("coud not connect to database");	 //here we are connecting to the database

	$selected = mysql_select_db("timetable", $dbhandle);		//accesing the login table


	if (file_exists($file)) 
	{

			$deleterecords = "TRUNCATE TABLE exams"; //empty the table of its current records

	   	    mysql_query($deleterecords);


   		 //Import uploaded file to Database
    		$handle = fopen("timetable.csv", "r");


    		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
    		{

        		$import="INSERT into exams(course,venue,_date,duration) values('$data[0]','$data[1]','$data[2]','$data[3]')";

        		mysql_query($import) or die(mysql_error());

    		}

    		fclose($handle);

    		mysql_close();


    		header('location:timetablesuccess.php');

    }

  
	else 
	{
    	echo "404 Not Found
			  The requested resource could not be found but may be available in the future. Subsequent requests by the client are permissible.";  /// error 404 in case the c++ code doesnt execute successfully.
	}

?>





