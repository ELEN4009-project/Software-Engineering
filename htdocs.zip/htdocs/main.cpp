/** * * * * * * * * * * * * * * * * * * * * * * * * * * *
  * Author: Malose Mashishi (490307)                    *
  * Project: ELEN4009 (Software Engineering)            *
  * Date: 07 April 2016                                 *
  * version 5.2.3                                       *
  * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <fstream>
#include <string.h>
#include <vector>
#include "date.h"
#include "venue.h"
#include "course.h"
#include "timetable.h"

using namespace std;

void getVenues(vector<venue>& venues, string name);
void getCourses(vector<course>& courses, string name);
bool allAllocated(vector<course>& courses);
void output(vector<timetable>& table);
void errorOutput(vector<course>& courses, vector<double>& errors);

int main()
{
	vector<venue> venues;
	vector<course> courses;
	vector<timetable> table;
	
	vector<double> errors;		// averaged sum of errors per day
	vector<double> errors_per_day;	// changes daily

	// it is assumed that courses in the text file are in descending order in size

	getVenues(venues, "venues.csv");
	getCourses(courses, "courses.csv");


	// set starting day
	date examday(20, 05, 2016);
	
	bool done = false;
	int iteration =0;
	
	// a month's worth of iterations
	while(!allAllocated(courses))
	{
		for(int i=0; i< venues.size(); ++i)
		{
			int temp_size = 0; 	// size of the students allocated to the venue
			for(int j=0; j < courses.size(); ++j)
			{
				if(!courses.at(j).isAllocated())
				{
					if(temp_size + courses.at(j).size() > venues.at(i).getCapacity())
					{
						double error = venues.at(i).getCapacity() - temp_size;
						errors_per_day.push_back(error/venues.at(i).getCapacity() *100);

						j = courses.size();
					}

					else
					{
						timetable _tt(courses.at(j).name(), courses.at(j).duration(), examday.day(), examday.month(), examday.year(), (venues.at(i)).name() );

						table.push_back(_tt);
						temp_size += (courses.at(j)).size();
						courses.at(j).allocateVenue(true);
						
					}
					
				}
			}
			
		}
		
		double sum_of_daily_averages = 0;
		for(int i = 0; i<errors_per_day.size(); i++)
		{
			sum_of_daily_averages += errors_per_day.at(i);
		}

		errors.push_back(sum_of_daily_averages/errors_per_day.size());
		
		errors_per_day.clear();		
		
		examday.incrementDay();

		while(!examday.itsSchoolDay())
			examday.incrementDay();
		
		iteration++;

	}
	
	errorOutput(courses, errors);

   	output(table);

	return 0;

}


void getVenues(vector<venue>& venues, string name)
{

	ifstream infile("venues.txt");

	if(!infile.is_open())
		cout << "could not open venues file" << endl;
	else
	{
		while(!infile.eof())
		{	
			string temp_venue;
			int temp_size;
			infile >> temp_venue >> temp_size;
			venue _venue(temp_venue, temp_size);
			venues.push_back(_venue);
		}

		venues.erase (venues.begin()+venues.size()-1);
	}
}

void getCourses(vector<course>& courses, string name)
{
	ifstream infile("input.txt");

	if(!infile.is_open())
		cout << "could not open courses file" << endl;
	else
	{
		while(!infile.eof())
		{
			string temp_name;
			int temp_size;
			string duration;

			infile >> temp_name >> temp_size >> duration;
			
			course _course(temp_name, temp_size, duration);

			courses.push_back(_course);
		}
		
		courses.erase (courses.begin()+courses.size()-1);
	}
	
}

bool allAllocated(vector<course>& courses)
{
	for(int j =0; j < courses.size(); j++)
		if(!(courses.at(j)).isAllocated())
			return false;
	return true;
}

void output(vector<timetable>& table)
{
    ofstream outfile("timetable.csv", ios::out);
	
	for(int i = 0; i<table.size(); i++)
		outfile << table.at(i).name() << "," << table.at(i).venue() << "," << table.at(i).day() <<"."<< table.at(i).month() <<"."<<table.at(i).year() << "," << table.at(i).duration() <<  endl;

	outfile.close();
}


void errorOutput(vector<course>& courses, vector<double>& errors)
{
	ofstream outfile("errors.txt", ios::out);

	int unallocated = 0;
	for(int i = 0; i < courses.size(); i++)
	{
		if(!courses.at(i).isAllocated())
			unallocated++; 
		
		if(i == (courses.size() - 1) )
		{
			for(int j =0; j< errors.size(); j++)
				outfile << j+1 << " " << errors.at(j) << endl;
		}
	}

		

	outfile.close();

}



