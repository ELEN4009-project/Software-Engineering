#ifndef VENUE_H
#define VENUE_H

#include <iostream>
#include <string.h>

using namespace std;

class venue
{
	public:
		venue(string venue, int capacity)
		{	
			_isValid = true;
			_venue = venue;
		
			if(capacity > 0)
				_capacity = capacity;
			else 
				_isValid = false;
		}

		int getCapacity()
		{
			return _capacity;
		}
	
		bool isValid()
		{
			return _isValid;
		}

		string name()
		{
			return _venue;
		}
	
	private:
		string _venue;
		int _capacity;
		bool _isValid;
		
};


#endif
