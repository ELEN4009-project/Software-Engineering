#ifndef DATE_H
#define DATE_H
#include <iostream>

using namespace std;

class date
{
public:
	date(int day, int month, int year)
	{
		_day = day;
		_month = month;
		_year = year;
	}

	int day(){ return _day;}
	
	int month(){return _month;}

	int year(){return _year;}
	
	void incrementDay()
	{
		if (isMonthEnd())
		{
			if(_month == 12)
			{
				_month = 1;
				_day = 1;
				_year++;
			}
			
			else
			{
				_month++;
				_day = 1;
			}
		}
		else
			_day++;
	}
	
	bool itsSchoolDay()
	{
		dayOfWeek();
		return _schoolDay;
	}

private:
	void dayOfWeek()
	{
		static int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
		int year = _year;
		year -= _month < 3;
		
		int dayOfWeek = (year + year/4 - year/100 + year/400 + t[_month-1] + _day) % 7;	
		
		if( dayOfWeek > 5 || dayOfWeek <1)
			_schoolDay = false;
		else
			_schoolDay = true;
	}
	
	bool isMonthEnd()
	{
		switch(_month)
		{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 12:
			{
				if(_day == 31)
					return true;
			}
			case 4:
			case 6:
			case 9:
			case 11:
			{
				if(_day == 30)
					return true;
			}

			case 2:
			{
				if(isLeapYear())
				{	if(_day == 29)
						return true;
				}
				else 
					if(_day == 28)
						return true;
			}
			
			default:
				return false;
		}
		
	}
	
	bool isLeapYear()
	{
		if(_year%4 !=0 )
			return false;
		else 
			if(_year % 100 != 0)
				return true;
			else
				if(_year %400 != 0)
					return false;
				else
					return true;
	}

	int _day;
	int _month;
	int _year;
	bool _schoolDay;

};

#endif
