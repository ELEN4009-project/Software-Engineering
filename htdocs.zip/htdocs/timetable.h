#ifndef TIMETABLE_H
#define TIMETABLE_H

#include "course.h"
#include "date.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>

using namespace std;

class timetable
{
public:
	timetable(string name, string duration, int day, int month, int year, string venue):
	    _name(name),
	    _duration(duration),
	    _day(day),
	    _month(month),
	    _year(year),
	    _venue(venue)
	{

	}


    /// getters
	string name(){return _name;}
    string time(){return _time;}
    string duration(){return _duration;}
    int day(){return _day;}
    int month(){return _month;}
    int year(){return _year;}
    string venue(){return _venue;}


private:
	string _name;
	string _time;
	string _duration;
	int _day;
	int _month;
	int _year;
	string _venue;
};
#endif
