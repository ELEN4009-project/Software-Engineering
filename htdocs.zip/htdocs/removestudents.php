<?php

	$username = "root";
	$password = "tphali";
	$hostname = "localhost";


	$dbhandle = mysql_connect($hostname, $username, $password) or die ("coud not connect to database");	 //here we are connecting to the database

	$selected = mysql_select_db("login", $dbhandle);		//accesing the login table

	$myusername = $_POST['user'];
	$mypassword = $_POST['pass'];


	$import="DELETE into students(Username, Password) values('$myusername','$mypassword')";

    mysql_query($import) or die(mysql_error());

    mysql_close();
?>

    <h1>Succesfully removed student crendential</h1> 

  	<a href = 'addstudents.html'>Continue to remove students</a>
	<a href = 'login_success1.php'>Go back</a>


