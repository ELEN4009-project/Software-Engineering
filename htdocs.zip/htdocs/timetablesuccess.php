<!DOCTYPE html>
<html>
<head>
<title>Account</title>
<link href="stylesheet.css" rel="StyleSheet" />
<script src="jquery-1.12.0.min.js"></script>
<script src="script.js"></script>
</head>
	<body  align = "center">
	<h1><p style="color:red">Successfully Generated Examination Timetable</p></h1>
	
    <h3> 
	<a href = "logout.php">Logout</a><br>
	<a href = "viewtimetable.php">Clich here to view timetable</a>
    </h3>
   
</html>