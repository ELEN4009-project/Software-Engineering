<!DOCTYPE html>
<html>
<head>
<title> home </title>
<link href="stylesheet.css" rel="StyleSheet" />
<script src="jquery-1.12.0.min.js"></script>
<script src="script.js"></script>
</head>
<header>
<nav align ="right">

	          <a class="current" title= "Homepage"  class="active">
                           Home
                           </a>   |           
                      
                           <a href= "about.html" title="about"
                            title=”Find out more about Timetable Management System.”>
                           About
                           </a>   |                 
                  
                       <a href="contacts.html"
                      title= "Contacts">
                      Contacts
                     </a>
 </nav>
</header>

	<body class="index">
	<h1><p style = "color: red" align ="center"> Welcome to TimeTable Scheduling Software</p></h1>
	<form onsubmit="return validate()" action="login.php" method="POST" class="index">

		<p class="index">Username:</p><input type="text" name = "user" id="Username"/>
		<p  class="index">Password:</p><input type="password" name = "pass" id="Password" />
		<br/>


		<input type="submit" value="Login" />

	</form>
	</body>
</html>	