<?php

	$username = "root";
	$password = "tphali";
	$hostname = "localhost";


	$dbhandle = mysql_connect($hostname, $username, $password) or die ("coud not connect to database");	 //here we are connecting to the database

	$selected = mysql_select_db("login", $dbhandle);		//accesing the login table

	$myusername = $_POST['user'];
	$mypassword = $_POST['pass'];

	$myusername = stripslashes($myusername);
	$mypassword = stripslashes($mypassword);

	$query1 = "SELECT * FROM administrator WHERE Username ='$myusername' and Password = '$mypassword'";
	$query2 = "SELECT * FROM students WHERE Username ='$myusername' and Password = '$mypassword'";

	
	$result1 = mysql_query($query1);
	$result2 = mysql_query($query2);


	$count1 = mysql_num_rows($result1);
	$count2 = mysql_num_rows($result2);


	mysql_close();


	if($count1 == 1)
	{
		$seconds = 5 + time();
		setcookie(loggedin, date("F jS - g:i a"), $seconds);
		header("location:login_success1.php");
	} 

	elseif($count2 == 1)
	{

		$seconds = 5 + time();
		setcookie(loggedin, date("F jS - g:i a"), $seconds);
		header("location:login_success2.php");

	}

	else
	{
		header("location:unsuccessful.php");
	}


?>


	