#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include <string.h>

using namespace std;

enum Time{morning, afternoon};


class course
{
public:
	course(string course, int size, string exam_duration)
	{
		_isValid = true;
		_course = course;
		_time = morning;
		_allocated = false;
        	_duration = exam_duration;
		
		if(size > 0)
			_size = size;
		else
			_isValid = false;
	}


	int size()
	{
		return _size;
	}

	void setTime(Time time)
	{
		_time = time;
	}

	Time time()
	{
		return _time;
	}
	string duration()
	{
		return _duration;
	}

	void allocateVenue(bool venue)
	{
		_allocated = venue;
	}

	bool isAllocated()
	{
		return _allocated;
	}

	bool valid()
	{
		return _isValid;
	}

	string name()
	{
		return _course;
	}

private:
	string _course;
	int _size;
	bool _isValid;
	Time _time;
	string _duration;
	bool _allocated;

};

#endif
