
function validate()
{
   
  username = document.forms[0].Username.value;
  password = document.forms[0].Password.value;
  if(username == "" || password == "")
  {
   alert("incomplete user credentials");
   return false;
  }
}
