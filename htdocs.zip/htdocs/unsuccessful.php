<!DOCTYPE html>
<html>
<head>
<title>Account</title>
<link href="stylesheet.css" rel="StyleSheet" />
<script src="jquery-1.12.0.min.js"></script>
<script src="script.js"></script>
</head>
	<body  align="center" id="unsuccessful" >
	<p style="color: purple">
	<h2>You have entered invalid password or username.<br>
	Please retype carefully or contact administrator.</h2>
	</p>

	<a href = "index.php" style="color: blue">Go to Homepage</a>
  </body>
</html>