<?php

	$username = "root";
	$password = "tphali";
	$hostname = "localhost";


	$dbhandle = mysql_connect($hostname, $username, $password) or die ("coud not connect to database");	 //here we are connecting to the database

	$selected = mysql_select_db("timetable", $dbhandle);		//accesing the database = timetable


	$query = "SELECT * FROM exams";

	$result = mysql_query($query);

	echo "<html>
	            <style>
       table, th, td {
                      border: 1px solid black;
                      border-collapse: collapse;
                     }
              th, td {
                     padding: 5px;
                    }
               
                        
              </style>
	            <table style='width:100%'> 
	            	<caption style ='black: red'><h2><b>Examanition Timetable</b><h2></caption>	
		             <tr align='left'> <th>Course</th>
		                  <th>Venue</th>
		                  <th>Date</th>
		                  <th>Duration</th>
		             </tr>";

	while($rows = mysql_fetch_array($result)):

		$course = $rows['course'];
		$venue = $rows['venue'];
		$date = $rows['_date'];
		$duration = $rows['duration'];

		 echo "
		       
		             <tr>
		             <td>$course</td>
		             <td>$venue</td>
		             <td>$date</td>
		             <td>$duration</td> 
		             </tr>  

		     
		     ";

	endwhile;
	echo "</table></html>";

	mysql_close();

?>